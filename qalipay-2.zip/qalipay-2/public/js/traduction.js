
i18next
.use(window.i18nextHttpBackend)
.init({
   lng: 'fr', // if you're using a language detector, do not define the
   debug: true,
   backend: {

       loadPath:'http://localhost/hlc/qalipay-2/lang/{{lng}}/translation.json'
     }
});



function translate() {
    // Retrieve all elements with data-i18n attribute
    const elementsWithI18n = document.querySelectorAll('[data-i18n]');
    
        elementsWithI18n.forEach(element => {
        const key = element.getAttribute('data-i18n');
        const translatedText = i18next.t(key);
        element.innerHTML = translatedText;
        
    });
} 
function handleTranslate(lang){
    i18next
    .changeLanguage(lang).then((t) => {
      translate()
    });
}
         
