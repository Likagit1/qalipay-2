function Calcul() {
    const nbEmpoyees = parseInt(document.getElementById('nbsal').value);
    const budgetAlloue = parseInt(document.getElementById('budgetAlloue').value);
    

    const budgetMensuelleGlobal = (nbEmpoyees * budgetAlloue);

    if(budgetAlloue >= 30000)
    {
        
        const economieMensuelle = (30000 * 0.37 * nbEmpoyees);
        const economieAnnuelle = (economieMensuelle * 12);

        const economieMensuelleSalarie = (30000 * 0.16);
        const economieAnnuelleSalarie = (economieMensuelleSalarie * 12);


        document.getElementById('soldEntreprise').textContent = numStr(budgetMensuelleGlobal.toFixed(0)) + ' FCFA';
        document.getElementById('month').textContent = numStr(economieMensuelle.toFixed(0)) + ' FCFA / mois d\'economie mensuelle';
        document.getElementById('year').textContent = numStr(economieAnnuelle.toFixed(0)) + ' FCFA / mois d\'economie annuelle';
        document.getElementById('yearSalarie').textContent = numStr(economieAnnuelleSalarie.toFixed(0)) + ' FCFA / an';
    }else {
        const economieMensuelle = (budgetAlloue * 0.37 * nbEmpoyees);
        const economieAnnuelle = (economieMensuelle * 12);

        const economieMensuelleSalarie = (budgetAlloue * 0.16);
        const economieAnnuelleSalarie = (economieMensuelleSalarie * 12);

        document.getElementById('soldEntreprise').textContent = numStr(budgetMensuelleGlobal.toFixed(0)) + ' FCFA';
        document.getElementById('month').textContent = numStr(economieMensuelle.toFixed(0)) + ' FCFA / mois d\'economie mensuelle';
        document.getElementById('year').textContent = numStr(economieAnnuelle.toFixed(0)) + ' FCFA / mois d\'economie annuelle';
        document.getElementById('yearSalarie').textContent = numStr(economieAnnuelleSalarie.toFixed(0)) + ' FCFA / an';
    }
    


    
}

document.addEventListener('DOMContentLoaded', function () {
    const form = document.querySelector('#simulation-form');
    const budgetAlloueInput = document.getElementById('budgetAlloue');
    const nbsalInput = document.getElementById('nbsal');
    form.addEventListener('input', Calcul); 

    budgetAlloue.addEventListener('input', function () {
        
        if (budgetAlloueInput.value === '') {
            budgetAlloueInput.value = 0;
        }
    });

    nbsal.addEventListener('input', function () {
        
        if (nbsalInput.value === '') {
            nbsalInput.value = 1;
        }
    });
});

function numStr(a, b) {
    a = '' + a;
    b = b || ' ';
    var c = '',
        d = 0;
    while (a.match(/^0[0-9]/)) {
      a = a.substr(1);
    }
    for (var i = a.length-1; i >= 0; i--) {
      c = (d != 0 && d % 3 == 0) ? a[i] + b + c : a[i] + c;
      d++;
    }
    return c;
  }

