
        const toggle = document.querySelector(".toggle-nav")
        const menu = document.querySelector(".menu")
 
        toggle.addEventListener('click',()=>{

            menu.classList.toggle('mobile-menu');
        })

        ScrollReveal().reveal('.cover-left', {
            origin: 'bottom',
            distance: '150px',
            opacity:"0",
            duration:800,
            mobile:false
        });

        ScrollReveal().reveal('.cover-right', {
            origin: 'right',
            distance: '100px',
            opacity:"0",
            delay: 500,
            mobile:false

        });
        ScrollReveal().reveal('.adventure-card1', {
            origin: 'left',
            distance: '100px',
               duration:800,
            opacity:"0",
            mobile:false

        });
        ScrollReveal().reveal('.adventure-card2', {
            origin: 'right',
            distance: '100px',
               duration:800,
            opacity:"0",
            mobile:false

        });
        ScrollReveal().reveal('.about-right', {
            origin: 'left',
            distance: '100px',
            opacity:"0",
               duration:800,
            delay:375,
            mobile:false

        });
        ScrollReveal().reveal('.img-about', {
            origin: 'right',
            distance: '100px',
            opacity:"0",
               duration:800,
            delay:375,
            mobile:false

        });
        ScrollReveal().reveal('.avantage-card1', {
            origin: 'left',
            distance: '100px',
            opacity:"0",
               duration:800,
            delay:375,
            mobile:false

        });
        ScrollReveal().reveal('.avantage-card2', {
            origin: 'right',
            distance: '100px',
            opacity:"0",
               duration:800,
            delay:375,
            mobile:false

        });
        ScrollReveal().reveal('.images', {
            origin: 'top',
            distance: '100px',
            opacity:"0",
            duration:800,
            delay:375,
            mobile:false

        });
        ScrollReveal().reveal('.imgs-container', {
            origin: 'top',
            distance: '100px',
            opacity:"0",
            duration:800,
            delay:375,
            mobile:false

        });
        ScrollReveal().reveal('.step-1', {
            origin: 'left',
            distance: '100px',
            opacity:"0",
            duration:800,
            delay:375,
            mobile:false

        });
        ScrollReveal().reveal('.step-2', {
            origin: 'right',
            distance: '100px',
            opacity:"0",
            duration:800,
            delay:500,
                        mobile:false

        });
        ScrollReveal().reveal('.step-3', {
            origin: 'left',
            distance: '100px',
            opacity:"0",
            duration:800,
            delay:575,
            mobile:false

        });
        ScrollReveal().reveal('.step-4', {
            origin: 'right',
            distance: '100px',
            opacity:"0",
            duration:800,
            delay:600,
            mobile:false

        });
        ScrollReveal().reveal('.img-join', {
            origin: 'bottom',
            distance: '100px',
            opacity:"0",
            duration:800,
            delay:375,
            mobile:false

        });

        ScrollReveal().reveal('.contact-item-form', {
            origin: 'left',
            distance: '100px',
            opacity:"0",
            duration:800,
            mobile:false

        });

        ScrollReveal().reveal('.contact-info', {
            origin: 'right',
            distance: '100px',
            opacity:"0",
            duration:800,
            mobile:false

        });


        


