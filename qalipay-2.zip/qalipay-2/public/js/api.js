     

        const  submitForm = ()=> {

            const nameInput = (document.getElementById('name').value);
            const emailInput = (document.getElementById('email').value);
            const telephoneInput = (document.getElementById('telephone').value);
            const companyInput = (document.getElementById('company').value);
            const postInput = (document.getElementById('post').value);
            const messageInput = (document.getElementById('message').value);

            const data = {
                name: nameInput,
                email: emailInput,
                tel: telephoneInput,
                entreprise: companyInput,
                fonction: postInput,
                message: messageInput
            };

            

            const options = {
                method: "POST", // Méthode HTTP
                headers: {
                    "Content-Type": "application/json" // Type de contenu (JSON)
                },
                body: JSON.stringify(data) // Conversion des données en JSON
            };

            const url = "https://qalipay.org/sendMail";

            fetch(url, options)
                .then(data => {
                    document.getElementById('successMessage').style.display = 'block';
                    resetForm();
                    document.body.scrollTop = 0; // Pour les navigateurs Chrome, Safari, Opera
                    document.documentElement.scrollTop = 0; 
                })
                .catch(error => {
                    document.getElementById('errorMessage').style.display = 'block';
                    resetForm();
                    document.body.scrollTop = 0; // Pour les navigateurs Chrome, Safari, Opera
                    document.documentElement.scrollTop = 0; 
                });

            
    
            return false;
        }


        const resetForm = ()=> {
            document.getElementById('name').value = '',
            document.getElementById('email').value = '',
            document.getElementById('telephone').value = '',
            document.getElementById('company').value = '',
            document.getElementById('post').value = '',
            document.getElementById('message').value = '';
        }
        