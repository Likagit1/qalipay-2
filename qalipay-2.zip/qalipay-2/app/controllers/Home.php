<?php
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';


class Home extends Controller{


    public function __construct()
    {

    }
   

    public function index(){
        $this->view('home/index');
    }
    public function marche(){
        $this->view('home/marche');
    }
    public function utilise(){
        $this->view('home/utilise');
    }

    public function contact(){
        $this->view('home/contact');
    }

    public function mention(){
        $this->view('home/mention');
    }
    public function faq(){
        $this->view('home/faq');
    }
    public function pdp(){
        $this->view('home/pdp');
    }

    public function sendMail(){
        $data = json_decode(file_get_contents('php://input'), true);

        $body="
        <p>Vous avez un message d'un visiteur ".$data['name'].",</p>
            
        <p>Téléphone : ".$data['tel']."</p>
    
        <p>Entreprise : ".$data['entreprise']."</p>
    
        <p>Fonction : ".$data['fonction']."</p>
    
        <p>Message : </p>
        <p>".$data['message']."</p>";


        $mail = new PHPMailer(true);
        $mail->CharSet = "UTF-8";
        $mail->isSMTP();                                            //Send using SMTP
        $mail->Host       = 'mail.qalipay.org';                     //Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
        $mail->Username   = 'hello@qalipay.org';                     //SMTP username
        $mail->Password   = 'beyond2023@';                               //SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
        $mail->Port       = 465;    

        // Destinataire
        $mail->setFrom($data['email']); // Adresse de l'expéditeur
        $mail->addAddress('hello@qalipay.org');

        // Contenu de l'e-mail
        $mail->isHTML(true);
        $mail->Subject = "Nouveau message d'un visiteur";
        $mail->Body = $body; 



        if ($mail->send()) {
            echo 'E-mail sent successfully';
        } else {
            echo 'E-mail could not be sent. Mailer Error: ' . $mail->ErrorInfo;
        }

        
    }
    

}