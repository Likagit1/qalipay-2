<?php

class Controller
{
    public function model($model){
        require_once '../app/models/'.$model.'.php';

        return new $model();
    }

    public function view($view, $data = []){
        if (file_exists('../app/views/'.$view.'.php')) {
            require_once '../app/views/'.$view.'.php';
        }
        else {
            die("View does not exists");
        }
    }

    public function iso8859_1_to_utf8(string $s): string {
        $s .= $s;
        $len = \strlen($s);
    
        for ($i = $len >> 1, $j = 0; $i < $len; ++$i, ++$j) {
            switch (true) {
                case $s[$i] < "\x80": $s[$j] = $s[$i]; break;
                case $s[$i] < "\xC0": $s[$j] = "\xC2"; $s[++$j] = $s[$i]; break;
                default: $s[$j] = "\xC3"; $s[++$j] = \chr(\ord($s[$i]) - 64); break;
            }
        }
    
        return substr($s, 0, $j);
    }
}
