<?php

/* define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'bd_tourisme'); */


define('APPROOT', dirname(dirname(__FILE__)));

define('URLROOT', 'http://localhost/hlc/qalipay-2');

