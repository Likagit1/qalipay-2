<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Qalipay | FAQ</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="pdp.css">
    <link rel="stylesheet" href="devis.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter&family=Roboto&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter&display=swap" rel="stylesheet">

    <link rel="apple-touch-icon" sizes="76x76" href="assets/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/favicon/favicon-16x16.png">
    <link rel="manifest" href="assets/favicon/site.webmanifest">
    <link rel="mask-icon" href="assets/favicon/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">

    <script src="https://kit.fontawesome.com/3f72594c3c.js" crossorigin="anonymous"></script>
</head>

<body>
    <header>
        <nav class="container">
            <div class="logo">
                <a href="index.html" id="presentation">
                    <img src="assets/Qalipay_Logo 1.png" alt="Qalipay_Logo" title="Qalipay Logo">
                </a>
            </div>
            <div class="menu">
                <a href="index.html" id="presentation" class="menu-link">Présentation</a>
                <a href="Commentcamarche.html" id="commentcamarche" class="menu-link">Comment ça marche ?</a>
                <a href="Oulutilise.html" id="oulutilise" class="menu-link">Où l’utiliser ?</a>
                <a href="contact.html" id="contact" class="menu-link">Contactez-nous</a>
            </div>
            <div class="login">
                <a href="">
                    Se connecter</a>
            </div>
            <img src="assets/bars-solid.svg" class="toggle-nav" alt="bars-solid">
        </nav>
    </header>
    <main>
        <section>
            <div class="faq-container">
                <div class="faq-commercant">
                    <p class="faq-title">PROTECTION DES DONNÉES PERSONNELLES</p>
                    <div class="faq-describe">
                        <p class="faq-text">Dans le cadre de l’inscription et/ou de l’abonnement aux Services Aline, en
                            créant un compte Aline, vous êtes amenés à fournir à QALIPAY SAS au Capital social <br /> de
                            1 000
                            000 FCFA immatriculé au RCCM d’Abidjan sous le numéro RC : CI-ABJ-2018-B-27786 (ci-après
                            désignée « QALIPAY ») des données personnelles vous concernant.</p>
                    </div>
                    <p class="faq-sub-title">FINALITÉS</p>
                    <div class="faq-describe">
                        <p class="faq-text">Aline souhaite vous faire bénéficier des meilleurs services. Dans ce cadre,
                            nous traitons vos données relatives à votre utilisation de nos Services afin de vous fournir
                            des services adaptés à vos centres d’intérêts, vos besoins ou vos usages, vous recommander
                            des Services plus pertinents ou mesurer l’impact de nos campagnes publicitaires qui vous
                            sont présentées et de les personnaliser.</p>
                        <p class="faq-text">Nous utilisons ainsi vos données notamment en vue des finalités et sur le
                            fondement des bases légales (loi ivoirienne n°2013- 450 du 19 juin 2013 relative à la
                            protection des données à caractère personnel) suivantes :</p>
                        <table class="pdp-table">
                            <tr>
                                <th>Finalités</th>
                                <th>Base légales</th>
                            </tr>
                            <tr>
                                <td>
                                    <p class="faq-text">Vous offrir les services et contenus liés à l’inscription
                                        et/ou l’abonnement que vous avez souscrit ou au compte que vous avez créé.</p>
                                    <p class="faq-text">Gérer l’inscription et le suivi de votre abonnement</p>
                                </td>
                                <td>
                                    <p class="faq-text">Contrat</p>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <p class="faq-text">Détecter et prévenir la fraude et les contentieux.</p>
                                    <p class="faq-text">Etablir des statistiques à des fins de mesures d’audience et de
                                        suivi de la qualité.</p>
                                    <p class="faq-text">Enregistrer les échanges téléphoniques avec nos conseillers
                                        clientèles à des fins de suivi de la qualité.</p>
                                </td>
                                <td>
                                    <p class="faq-text">Intérêt légitime (prévention de la fraude et de gestion des
                                        contentieux, compréhension de vos attentes et d’établissement de statistiques et
                                        d’études relatives à l’utilisation de nos services, suivi de la qualité).</p>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <p class="faq-text">Créer et partager des segments d’audience ou des profils
                                        d’utilisateurs en fonction de votre utilisation de nos services et/ou de vos
                                        centres d’intérêts.</p>
                                    <p class="faq-text">Mesurer votre intérêt pour les publicités qui vous sont
                                        présentées.</p>
                                    <p class="faq-text">Mesurer votre intérêt pour nos services et nos sites et les
                                        améliorer.
                                        Recommander du contenu en fonction de vos centres d’intérêt.
                                    </p>
                                    <p class="faq-text">Personnaliser la publicité qui vous est présentée en fonction de
                                        votre utilisation de nos services ou de celles des services tiers.</p>
                                </td>
                                <td>
                                    <p class="faq-text">Intérêt légitime (personnalisation des services et des offres,
                                        mesure de la performance des campagnes publicitaires que nous diffusons,
                                        compréhension de vos attentes et amélioration de nos services, promotion de nos
                                        services et de ceux des tiers) sous réserve de vos droits ou dans notre
                                        Politique cookies.</p>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <p class="faq-text">Vous adressez par tout moyen (courrier postal, email, téléphone,
                                        sms, notifications), des informations vous permettant de mieux connaître nos
                                        services ainsi que des offres commerciales relatives à nos services ou à ceux de
                                        nos partenaires.</p>
                                </td>
                                <td>
                                    <p class="faq-text">Intérêt légitime de promotion de nos services et de ceux de nos partenaires sous réserve de vos droits détaillés.</p>
                                </td>
                            </tr>
                        </table>
                    </div>
                    <p class="faq-sub-title">DONNEES COLLECTÉES </p>
                    <div class="faq-describe">
                        <p class="faq-text">Nous collectons les données personnelles suivantes :</p>
                        <ul>
                            <li class="faq-text">Vos données d’identification et d’inscription à nos services (nom,
                                prénom, âge, adresse domicile, coordonnées téléphoniques, email, photo)
                            </li>
                            <li class="faq-text">Données professionnelles (ID RCCM, DFE ou autre justificatif
                                d’existence légale)</li>
                            <li class="faq-text">Vos données d’utilisation de nos services</li>
                            <li class="faq-text">Les données de réaction aux publicités ciblées qui vous sont proposées
                            </li>
                        </ul>
                    </div>
                    <p class="faq-sub-title">DESTINATION DE VOS DONNÉES PERSONNELLES</p>
                    <div class="faq-describe">
                        <p class="faq-text">Vos données personnelles sont destinées à nos sous-traitants qui
                            interviennent dans la fourniture de nos services et, le cas échéant, en conformité avec la
                            réglementation à la protection des données personnelles, à nos partenaires commerciaux, ou à
                            des tiers intervenant dans la diffusion de publicités, sous réserve de vos droits garantis
                            par la réglementation applicable à la protection des données personnelles.</p>
                        <p class="faq-text">Toutefois, aucun partage ne sera effectué si vous n’avez pas consenti
                            préalablement.
                            Un tel partage ne peut se faire que sous les conditions suivantes :
                        </p>
                        <ul>
                            <li class="faq-text">Soit sous réserve de votre accord libre, spécifique et préalable que
                                vous pouvez fournir ou retirer à tout moment ;</li>
                            <li class="faq-text">Soit, lorsque la règlementation applicable ne requiert pas votre
                                accord, en garantissant d’autres mesures de protection de ces données : confidentialité,
                                pseudonymisation, cryptage, durée de conservation limitée au strict nécessaire, etc.
                            </li>
                        </ul>
                        <p class="faq-text">En tout état de cause, vous pouvez à tout moment, exercer vos droits auprès
                            de nous, exprimer votre accord ou le retirer.
                        </p>
                        <p class="faq-text">Enfin, les données personnelles sont également communiquées, sur demande
                            judiciaire ou administrative et afin de se conformer à toute loi ou règlementation en
                            vigueur, à des organismes publics, auxiliaires de justice, officiers ministériels, à qui
                            nous sommes tenus de répondre.
                        </p>
                    </div>
                    <p class="faq-sub-title">VOS DROITS
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">Pour exercer les droits indiqués ci-après, vous pouvez écrire : QALIPAY
                            S.A.S, à Abidjan, Cocody, 2 Plateaux, Boulevard des Martyrs, Immeuble BOTIWA, 3ème étage,
                            Appartement 549, sous réserve de préciser votre identité complète.</p>
                        <p class="faq-text">Dans les conditions prévues par la réglementation applicable à la protection
                            des données personnelles, vous disposez d’un droit d’accès, de rectification, et
                            d’effacement de vos données, ainsi que d’un droit à la limitation du traitement.</p>
                        <p class="faq-text">Lorsque vos droits portent sur certains usages de vos données qui sont
                            décrits dans notre politique cookies, les modalités d’expression de vos droits et de vos
                            préférences sont décrites directement dans cette politique de cookies afin que vous puissiez
                            identifier rapidement comment exercer vos droits qui s’attachent aux différents usages de
                            vos données.</p>
                        <p class="faq-text">En cas d’exercice du droit d’opposition aux sollicitations commerciales ou à
                            la personnalisation de vos recommandations, nous cesserons le traitement de vos données
                            personnelles, sauf en cas de motif(s) légitime(s) et impérieux pour le traitement, ou pour
                            assurer la constatation, l’exercice ou la défense de nos droits en justice, conformément à
                            la règlementation applicable.</p>
                        <p class="faq-text">Vous disposez également du droit de récupérer les données personnelles que
                            vous nous avez fournies et qui sont nécessaires à l’exécution du contrat souscrit auprès de
                            nous.</p>
                    </div>
                    <p class="faq-sub-title">
                        DURÉE DE CONSERVATION DE VOS DONNÉES PERSONNELLES
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">Vos données personnelles sont conservées selon des durées déterminées au
                            regard de nos finalités et des obligations légales nous incombant.</p>
                    </div>
                </div>

            </div>
        </section>
    </main>
    <footer class="footer">
        <div class="footer-container">
            <div class="footerA">
                <a href="index.html">
                    <img class="footer-logo" src="assets/Qalipay_Logo 1.png" alt="Qalipay_Logo" title="Qalipay Logo">
                </a>
                <p class="footer-about">Une solution mobile disponible sur android et ios qui permet aux employeurs des
                    entreprises et de la fonction publique de subventionner les déjeuners de leurs salariés pour
                    davantage de motivation et de bien-être au travail.</p>
            </div>
            <div class="footerB">
                <p class="footer-title">Informations</p><br>
                <div class="link-container">
                    <a href="ml.html" class="footer-link">Mentions légales</a>
                    <a href="#" class="footer-link">Protection des données personnelles</a>
                    <a href="faq.html" class="footer-link">FAQ QaliPay™</a>
                    <a href="contact.html" class="footer-link">Contactez-nous</a>
                </div>
            </div>
            <div class="footerC">
                <p class="footer-title">Télécharger l’appli QaliPay Connect®
                </p><br>
                <a href="">
                    <img src="assets/Apple-store-Google-Play.png" alt="">
                </a>
                <div class="reseaux-sociaux">
                    <a href="">
                        <img src="assets/facebook.png" alt="">
                    </a>
                    <a href="">
                        <img src="assets/linkedin.png" alt="">
                    </a>
                    <a href="">
                        <img src="assets/youtube.png" alt="">
                    </a>
                </div>
            </div>
        </div>
        <div style="margin-top:20px; margin-bottom:10px">
            <p class="copyrith" style="color: #fff;font-size: 1rem;font-weight: bolder;">
                <i class="fa-solid fa-phone"></i>
                <a href="tel:+225 27 22 42 78 85" style="color: #fff;text-decoration: none;">+225 27 22 42 78 85</a> /
                <a href="tel:+225 05 06 34 34 99" style="color: #fff;text-decoration: none;">+225 05 06 34 34 99</a>
            </p>
            <!--             <p class="copyrith" style="color: #fff;font-size: 1rem;font-weight: bolder;">
                    <i class="fa-regular fa-envelope"></i>
                    <a href="care@humancare.ci" class="ml-3">care@humancare.ci</a>
            </p> -->
        </div>
        <div>
            <p class="copyrith">
                @2023 QaliPay™, tous droits réservés
            </p>
        </div>
    </footer>

    <script src="index.js"></script>
</body>

</html>