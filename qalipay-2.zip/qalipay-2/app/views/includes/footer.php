<script src="<?=URLROOT;?>/js/index.js"></script>
<script src="<?=URLROOT;?>/js/simulation.js"></script>
<script src="<?=URLROOT;?>/js/api.js"></script>

<footer class="footer">
<div class="footer-container">
    <div class="footerA">
        <a href="<?=URLROOT;?>">
            <img class="footer-logo" src="assets/Qalipay_Logo 1.png" alt="Qalipay_Logo" title="Qalipay Logo">
        </a>
        <p class="footer-about" data-i18n="solution-mobile-description" id="solution-mobile-description">
            Une solution mobile disponible sur android et ios qui permet aux employeurs des entreprises et de la fonction publique de subventionner les déjeuners de leurs salariés pour davantage de motivation et de bien-être au travail.
        </p>
    </div>
    <div class="footerB">
        <p class="footer-title" data-i18n="informations" id="informations">Informations</p><br>
        <div class="link-container">
            <a href="mention-legale" class="footer-link" data-i18n="mentions-legales" id="mentions-legales">Mentions légales</a>
            <a href="donnees-personnelles" class="footer-link" data-i18n="protection-donnees" id="protection-donnees">Protection des données personnelles</a>
            <a href="faq" class="footer-link" data-i18n="faq-qalipay" id="faq-qalipay">FAQ QaliPay™</a>
            <a href="contactez-nous" class="footer-link" data-i18n="contactez-nous" id="contactez-nous">Contactez-nous</a>
        </div>
    </div>
    <div class="footerC">
        <p class="footer-title" data-i18n="telecharger-appli" id="telecharger-appli">Télécharger l’appli QaliPay Connect®</p><br>
    </div>
</div>

                <a href="">
                    <img src="assets/Apple-store-Google-Play.png" alt="">
                </a>
                <div class="reseaux-sociaux">
                    <a href="">
                        <img src="assets/facebook.png" alt="">
                    </a>
                    <a href="">
                        <img src="assets/linkedin.png" alt="">
                    </a>
                    <a href="">
                        <img src="assets/youtube.png" alt="">
                    </a>
                </div>
            </div>
        </div>
                <div style="margin-top:20px; margin-bottom:10px">
            <p class="copyrith" style="color: #fff;font-size: 1rem;font-weight: bolder;">
                <i class="fa-solid fa-phone"></i>
                <a href="tel:+225 27 22 42 78 85" style="color: #fff;text-decoration: none;">+225 27 22 42 78 85</a> / <a href="tel:+225 05 06 34 34 99" style="color: #fff;text-decoration: none;">+225 05 06 34 34 99</a>
            </p>
<!--             <p class="copyrith" style="color: #fff;font-size: 1rem;font-weight: bolder;">
                    <i class="fa-regular fa-envelope"></i>
                    <a href="care@humancare.ci" class="ml-3">care@humancare.ci</a>
            </p> -->
        </div>
        <div>
            <p class="copyrith" data-i18n="reserve" id="reserve">
                @2023 QaliPay™, tous droits réservés
            </p>
        </div>
    </footer>
    <script src="https://unpkg.com/i18next@23.6.0/dist/umd/i18next.js"></script>
<script src="https://cdn.jsdelivr.net/npm/i18next-http-backend@1.3.1/i18nextHttpBackend.min.js"></script>
<script src="http://localhost/hlc/qalipay-2/js/traduction.js"></script>

    