<header>

        <nav class="container">
            <div class="logo">
                <a href="<?=URLROOT;?>" id="presentation">
                    <img src="assets/Qalipay_Logo 1.png" alt="Qalipay_Logo">
                </a>
            </div>
            <div class="menu">
                <a href="<?=URLROOT;?>" id="presentation"data-i18n="presentation" class="menu-link <?=$_SERVER['REQUEST_URI']=='/hlc/qalipay-2/'?'active':''?>"> Présentation </a>
                <a href="<?=URLROOT;?>/comment-ça-marche" id="commentcamarche" data-i18n="commentcamarche"class="menu-link <?=urldecode($_SERVER['REQUEST_URI'])=='/hlc/qalipay-2/comment-ça-marche'?'active':''?>">Comment ça marche ?</a>
                <a href="<?=URLROOT;?>/ou-lutiliser" id="oulutilise"data-i18n="oulutilise" class="menu-link <?=urldecode($_SERVER['REQUEST_URI'])=='/hlc/qalipay-2/ou-lutiliser'?'active':''?>">Où l’utiliser ?</a>
                <a href="<?=URLROOT;?>/contactez-nous" id="contact"data-i18n="contact" class="menu-link <?=urldecode($_SERVER['REQUEST_URI'])=='/hlc/qalipay-2/contactez-nous'?'active':''?>">Contactez-nous</a> 
                
                <a href="#" id="traductone" style="display:flex;"  class="menu-link drapeau" onclick="handleTranslate('fr')"><img   src="https://img.icons8.com/emoji/48/france-emoji.png" alt="france-emoji" /></a>
                <a href="#" id="traductwo" style="display:flex;"  class="menu-link drapeau"  onclick="handleTranslate('en')"> <img  src="https://img.icons8.com/emoji/48/united-states-emoji.png" alt="united-states-emoji"/></a> 
            
                <a href="#"class="btn-connect" id="connecter"data-i18n="connecter" >
                    Se connecter</a>
            </div>
            <div class="login">
                <a href="#" id="connecter"data-i18n="connecter" >
                    Se connecter</a>
            </div>
            <img src="assets/bars-solid.svg" class="toggle-nav" alt="bars-solid">
        </nav>
    </header>



 


     