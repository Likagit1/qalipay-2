<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

      <!-- HTML Meta Tags -->
      <title>Qalipay - Achetez des Tickets Restaurant en ligne - Votre Solution Repas</title>
      <meta name="description" content="QaliPay est une plateforme digitale qui offre une solution de titres-resto aux employeurs du privé et du public pour subventionner les déjeuners de leurs salariés.">
      <meta name="keywords" content="Tickets Restaurant en ligne, Qalipay, Titres Resto, Acheter Tickets Restaurant, Solution Repas, Avantages Tickets Restaurant"/>

      <!-- Facebook Meta Tags -->
      <meta property="og:url" content="https://www.qalipay.org/">
      <meta property="og:type" content="website">
      <meta property="og:title" content="Qalipay - Achetez des Tickets Restaurant en ligne - Votre Solution Repas">
      <meta property="og:description" content="QaliPay est une plateforme digitale qui offre une solution de titres-resto aux employeurs du privé et du public pour subventionner les déjeuners de leurs salariés.">
      <meta property="og:image" itemprop="image" content="https://www.qalipay.org/public/assets/og_image.png">
    
      <!-- Twitter Meta Tags -->
      <meta name="twitter:card" content="summary_large_image">
      <meta property="twitter:domain" content="qalipay.org">
      <meta property="twitter:url" content="https://www.qalipay.org/">
      <meta name="twitter:title" content="Qalipay - Achetez des Tickets Restaurant en ligne - Votre Solution Repas">
      <meta name="twitter:description" content="QaliPay est une plateforme digitale qui offre une solution de titres-resto aux employeurs du privé et du public pour subventionner les déjeuners de leurs salariés.">
      <meta name="twitter:image" content="https://www.qalipay.org/public/assets/og_image.png">
    
      <!-- Meta Tags Generated via https://www.opengraph.xyz -->
        
    
    <link rel="stylesheet" href="<?=URLROOT;?>/css/style.css">
    <link rel="stylesheet" href="<?=URLROOT;?>/css/devis.css">
    <link rel="stylesheet" href="<?=URLROOT;?>/css/pdp.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter&family=Roboto&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter&display=swap" rel="stylesheet">
    
    <link rel="apple-touch-icon" sizes="76x76" href="<?=URLROOT;?>/assets/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="<?=URLROOT;?>/assets/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="<?=URLROOT;?>/assets/favicon/favicon-16x16.png">
    <link rel="manifest" href="<?=URLROOT;?>/assets/favicon/site.webmanifest">
    <link rel="mask-icon" href="<?=URLROOT;?>/assets/favicon/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
    
    <script src="https://unpkg.com/scrollreveal@4.0.0/dist/scrollreveal.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/3f72594c3c.js" crossorigin="anonymous"></script>

    
   </head>
<body>