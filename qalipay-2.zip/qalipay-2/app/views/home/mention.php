<?php
    require APPROOT . '/views/includes/head.php';
?>
<?php
    require APPROOT . '/views/includes/nav.php';
?>

<main>
        <section>
            <div class="faq-container">
                <div class="faq-commercant">
                    <p class="faq-title">MENTIONS LÉGALES</p>
                    <p class="faq-sub-title">INFORMATION ÉDITEUR</p>
                    <div class="faq-describe">
                        <p class="faq-text">
                            Ce site est édité par QALIPAY S.A.S. au capital de 1 000 000 FCFA, 
                            dont le siège social est situé à Abidjan, Cocody, 2 Plateaux, Boulevard des Martyrs,
                             Immeuble BOTIWA, 3ème étage, Appartement 549.
                        </p>
                        <p class="faq-text"> 
                            <b>Directeur de la publication </b>: Arthur B. GUEYE
                        </p>

                    </div>
                </div>
                <div class="faq-commercant">
                    <p class="faq-sub-title">INFORMATION HÉBERGEUR :</p>
                    <div class="faq-describe">
                        <p class="faq-text">
                            Ce site est hébergé par CLOUD4AFRICA SAS,
                             dont le siège social est situé à Cocody Riviéra Bonoumin – 10 BP 1742 Abidjan 10
                        </p>
                        

                    </div>
                    

                </div>
                <div class="faq-commercant">
                    <p class="faq-sub-title">DROITS D’AUTEUR / COPYRIGHT</p>
                    <div class="faq-describe">
                        <p class="faq-text">
                            Les marques et logos figurant sur ce Site sont des marques déposées par QALIPAY S.A.S, HLC GROUP,
                             les sociétés de son Groupe ou leurs partenaires. 
                             Leur mention n’accorde en aucune manière une licence ou un droit d’utilisation quelconque desdites marques,
                              qui ne peuvent donc être utilisées sans le consentement préalable et écrit du propriétaire de la marque sous peine de contrefaçon. 
                            L’ensemble des informations présentes sur ce Site peut être téléchargé, reproduit, imprimé sous réserve de : 

                              </p>
                              <p class="faq-text"> – n’utiliser de telles informations qu’à des fins personnelles et en aucune manière à des fins commerciales ;</p>
<p class="faq-text"> – ne pas modifier de telles informations ;</p>
<p class="faq-text">– reproduire sur toutes copies la mention des droits d’auteur de QALIPAY et/ou         HLC GROUP (« copyright »).</p>
<p class="faq-text">Toute autre utilisation non expressément autorisée est strictement interdite sans autorisation préalable et écrite de QALIPAY.</p>
            </div>
            </div>
            <div class="faq-commercant">
                <p class="faq-sub-title">RESPONSABILITÉ</p>
                <div class="faq-describe">
                    <p class="faq-text">
                        L'ensemble des informations accessibles via ce Site sont fournies en l’état.
                          </p>
                          <p class="faq-text"> QALIPAY ne donne aucune garantie, explicite ou implicite, et n’assume aucune responsabilité relative à l’usage, la copie,
                             la transmission et à toute utilisation des informations, de quelque nature qu’elles soient, contenues sur le Site.</p><br>
                          <p class="faq-text">QALIPAY n’est pas responsable ni de l’exactitude, ni des erreurs, ni des omissions contenues sur ce Site.</p><br>
                          <p class="faq-text">L’utilisateur est seul responsable de l’utilisation de telles informations.</p><br>
                          <p class="faq-text">QALIPAY se réserve le droit de modifier à tout moment les présentes notamment en actualisant ce Site.</p><br>
                          <p class="faq-text">QALIPAY ne pourra être responsable pour quel que dommage que ce soit tant direct qu’indirect, 
                            résultant d’une information contenue sur ce Site.</p><br>

                          <p class="faq-text">L’utilisateur s’engage à ne transmettre sur ce Site aucune information pouvant entraîner une responsabilité civile 
                            ou pénale et s’engage à ce titre à ne pas divulguer via ce Site des informations illégales, contraires à l’ordre public, 
                            aux bonnes mœurs ou diffamatoires.</p><br>
                            <p class="faq-text"> QALIPAY met tout en œuvre pour offrir aux utilisateurs des informations et/ou des outils disponibles et vérifiés, 
                                mais ne saurait être tenu pour responsable des erreurs, 
                                d’une absence de disponibilité des informations et/ou de la présence de virus sur son Site.</p><br>
                                <p class="faq-text">
                                    Les sites extérieurs à la société QALIPAY ayant un lien hypertexte ou autre avec le présent Site ne sont pas sous le contrôle
                                     de cette dernière et QALIPAY décline, par conséquent, toute responsabilité quant à leur contenu.
                                     L’utilisateur est seul responsable de leur utilisation.
                                </p><br>
                                <p class="faq-text">
                                    QALIPAY ne donne aucune garantie et n’assume aucune responsabilité relative à l’usage,
                                     la copie, la transmission et à toute utilisation des informations, de quelque nature qu’elles soient contenues sur le Site.
                                </p><br>

                          


        </section>
    </main>

    <?php
    require APPROOT . '/views/includes/footer.php';
?>