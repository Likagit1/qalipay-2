<?php
    require APPROOT . '/views/includes/head.php';
?>
<?php
    require APPROOT . '/views/includes/nav.php';
?>

<main>
        <section>
            <div class="faq-container">
                <div class="faq-commercant">
                    <p class="faq-title">Titres-Resto - Commerçant</p>
                    <p class="faq-sub-title">Je suis restaurateur / commerçant, quelles sont les démarches à effectuer
                        pour m’affilier et accepter les Titres-Resto
                        QaliPay™ ?</p>
                    <div class="faq-describe">
                        <p class="faq-text">L’acceptation des Titres-Resto QaliPay™ est réservée aux restaurateurs,
                            commerces
                            alimentaires et
                            assimilés.</p>
                        <p class="faq-text">Pour accepter les Titres-Resto QaliPay™ , vous deviez demander l’affiliation
                            de QaliPay™.
                            Ceci
                            est valable même si vous
                            reprenez un établissement qui prenait déjà les titres-resto.</p>
                        <p class="faq-text">Créer un dossier QaliPay™ – Restaurateur <br>Créer un dossier QaliPay™ –
                            Détaillant de fruits
                            et
                            légumes <br>Créer un dossier QaliPay™ – Autres commerces et activités alimentaires :
                        </p>
                        <ul>
                            <li class="faq-text">Commerce de bouche : boucherie, charcuterie-traiteur, boulangerie…</li>
                            <li class="faq-text">Grande surface, épicerie, supérette, alimentation générale,
                                établissement de vente de
                                détail de produits surgelés</li>
                            <li class="faq-text">Cantine, établissement de restauration collective</li>
                            <li class="faq-text">Société spécialisée dans la distribution automatique</li>
                        </ul>

                        <p class="faq-text">Ce lien a une durée de validité limitée !</p>
                        <p class="faq-text">Si vous n’avez pas reçu ce mail ou si le lien n’est plus valide, vous pouvez
                            vous affilier de
                            façon autonome depuis le <br>
                            site qalipay.com. Cliquez sur « Se connecter » puis sur « Commerçant », ou rdv directement
                            ici.</p>
                        <p class="faq-text">N’oubliez pas de vous munir de votre numéro compte contribuable et registre
                            de commerce:
                            vous en aurez besoin
                            pour valider votre affiliation à Titres-Resto QaliPay™ .</p>
                    </div>

                    <p class="faq-sub-title">Quelles sont les conditions tarifaires pour accepter les Titres-Resto
                        QaliPay™ ?</p>
                    <div class="faq-describe">
                        <p class="faq-text">Retrouvez les tarifs des prestations QaliPay Côte d’Ivoire pour le
                            remboursement des <b>Titres-Resto QaliPay™</b>
                            en <a href="">cliquant ici </a>.</p>
                    </div>
                    <p class="faq-sub-title">Est-ce que j’ai plusieurs numéros affiliés pour mes différents points de
                        vente ?</p>
                    <div class="faq-describe">
                        <p class="faq-text">Oui, chacun des points de vente doit être affilié auprès de QaliPay™. Un
                            code affilié est donc affecté à
                            chaque établissement.</p>
                    </div>
                    <p class="faq-sub-title">Comment s'affilier au réseau Titres-Resto QaliPay™ ?</p>
                    <div class="faq-describe">
                        <p class="faq-text">Vous pouvez vous affilier aux Titres-Resto QaliPay™ directement en ligne .
                            Votre affiliation ne sera validée
                            qu'à l'obtention de votre agrément.</p>
                    </div>
                    <p class="faq-sub-title">Comment accepter les transactions UBA?</p>
                    <div class="faq-describe">
                        <p class="faq-text">Vous devez mettre à jour votre TPE. Pour cela, munissez-vous de votre carte
                            de domiciliation envoyée par UBA et
                            contactez votre mainteneur qui vous aidera à le/les paramétrer.</p>
                        <p class="faq-text">Si votre TPE a été mis à jour, les transactions passeront en priorité sur le
                            réseau UBA.</p>
                    </div>
                    <p class="faq-sub-title">Est-ce que tous les TPE du marché sont compatibles avec la carte Ticket
                        Restaurant® ?</p>
                    <div class="faq-describe">
                        <p class="faq-text">Vous pouvez accepter les Ingenico.</p>
                        <p class="faq-text">Les transactions carte sur le réseau UBA sont acceptées uniquement avec un
                            TPE Ingenico.</p>
                    </div>
                    <p class="faq-sub-title">Pourquoi les transactions carte Titres-Resto QaliPay™ ne sont plus
                        acceptées par mon TPE ?</p>
                    <div class="faq-describe">
                        <ul>
                            <li class="faq-text">Vous avez changé de TPE et ne l’avez pas paramétré.</li>
                            <li class="faq-text">Vous avez changé de banque et vous ne nous avez pas communiqué votre
                                identifiant commerçant. Dans ce cas, mettez-le à
                                jour dans votre Espace partenaire rubrique Mon Point de vente</li>
                            <li class="faq-text">Votre agrément a été désactivé. Veuillez contacter QaliPay™</li>
                        </ul>
                    </div>
                    <p class="faq-sub-title">Dans quel cas un paiement par carte QaliPay Connect™ peut-il être refusé ?
                    </p>
                    <div class="faq-describe">
                        <ul>
                            <p class="faq-text">La transaction est refusée si :</p>
                            <li class="faq-text">Le paiement est inférieur à 500 FCFA.</li>
                            <li class="faq-text">Le solde disponible est nul.</li>
                            <li class="faq-text">Le paiement est supérieur au solde disponible sur la carte.</li>
                            <li class="faq-text">La carte de l’utilisateur n’est pas encore activée.</li>
                            <li class="faq-text">L’utilisateur a mis sa carte en opposition ou elle est désactivée par 3
                                codes PIN successifs erronés.</li>
                            <li class="faq-text">Le jour d’utilisation est un dimanche ou un jour férié.</li>
                            <li class="faq-text">Votre TPE n’est pas instancié (en contact et/ou sans contact).</li>
                            <li class="faq-text">Votre identifiant commerçant n’est pas encore connu dans nos systèmes.
                                Dans ce cas, ajoutez-le sur votre Espace
                                partenaire</li>
                            <li class="faq-text">Vous avez changé de banque et n’avez pas communiqué votre nouveau
                                numéro commerçant. Rendez-vous sur votre
                                Espace partenaire.</li>
                            <li class="faq-text">Si la demande d'autorisation est trop longue suite à une perte de
                                connexion ou une saturation de flux, la transaction peut se
                                solder par un Abandon débit.</li>
                        </ul>
                        <p class="faq-text">Les utilisateurs peuvent à tout moment vérifier leur solde avec
                            l’application mobile QaliPay Connect™ , le site Internet
                            QaliPay.com, le service SMS, ou encore par téléphone.</p>
                    </div>
                    <p class="faq-sub-title">
                        Quels sont les différents réseaux bancaires de la carte QaliPay Connect™ ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">La carte <b>QaliPay Connect™</b> peut être acceptée sur le réseau UBA ainsi que sur le réseau VISA</p>
                    </div>
                    <p class="faq-sub-title">Comment accepter les transactions VISA ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">Pour que les transactions VISA soient acceptées sur votre/vos TPE, vous
                            devez ajouter votre identifitant commerçant
                            (numéro à 7 chiffres que vous pouvez retrouver sur votre ticket de carte bancaire) et le nom
                            de votre banque sur
                            votre Espace partenaire</p>
                        <p class="faq-text">Merci de vérifier que votre numéro commerçant soit le même en paiement avec
                            et sans contact. Dans le cas contraire,
                            remplir les informations 2 fois.</p>
                    </div>
                    <p class="faq-sub-title">Quelle est la date de validité d’un Titre-Resto QaliPay™ ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">
                            Les Titre-Resto QaliPay™ sont valables jusqu’à l’expiration du contrat de l’entreprise et les Cartes QaliPay Connect™ ont une durée de validité de 3 ans (la date d’expiration étant mentionnée sur la carte)
                        </p>

                    </div>
                    <p class="faq-sub-title">Comment puis-je contacter le support partenaire si j'ai un problème ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">Vous pouvez contacter le support marchands QALIPAY via la formulaire de
                            contact rubrique en ligne sur
                            votre <a href="">Espace partenaire</a> rubrique Aide ou par téléphone au : 00 00 00 00
                            00 ( prix d’un appel
                            local - du lundi
                            au vendredi hors jours fériés de 9h à 17h ).
                        </p>

                    </div>
                </div>
                <div class="faq-Entreprise">
                    <p class="title">Titres-Resto - Entreprise</p>
                    <p class="faq-sub-title">Qui peut bénéficier des Titres-Resto QaliPay™ ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">Tout collaborateur lié à une entreprise ou à une collectivité par un contrat
                            de travail peut bénéficier de la carte
                            <b>QaliPay Connect™</b> . Elle concerne l’ensemble des salariés : CDI, CDD, intérimaires,
                            stagiaires et ne doit pas faire
                            l’objet de discriminations.
                        </p>
                        <p class="faq-text">Enfin, les salariés qui travaillent à temps partiel peuvent obtenir des
                            titres restaurants dès lors que leurs heures de
                            travail sont entrecoupées de pauses de repas.
                        </p>
                        <p class="faq-text">Les télétravailleurs bénéficient des mêmes droits et avantages que les
                            salariés travaillant dans les locaux de
                            l'entreprise.
                        </p>
                    </div>
                    <p class="faq-sub-title">Quel montant maximal puis-je proposer à mes salariés pour que ma
                        participation soit totalement
                        exonérée de charges ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">Le plafond d'exonération est de 30 000 FCFA par salarié par mois. Ainsi,
                            vous pouvez proposer à vos collaborateurs un
                            rechargement compris entre : <br>
                            - 1 500 FCFA par jour avec une participation employeur de 100% <br>
                            - 3 000 FCFA par jour avec une participation employeur de 50%.
                        </p>
                        <p class="faq-text">D’après la directive N° 2408/SEPMBPE/DGI-DLCD de la Direction Générale des
                            Impôts de Côte d'Ivoire
                        </p>
                    </div>
                    <p class="faq-sub-title">Les avantages des Titres-Resto QaliPay™ pour l’employeur
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">Le Titre-Resto QaliPay™ représente un coût pour l’employeur mais possède
                            plusieurs avantages.</p>
                        <p class="faq-text">Les Titres-Resto QaliPay™ permettent à l’employeur de bénéficier d’une
                            exonération de charges
                            sociales et fiscales sur sa contribution. Cette exonération a pour limite 30 000 FCFA par
                            mois travaillé et
                            par salarié au contraire d’une augmentation de salaire de même montant.
                        </p>
                        <p class="faq-text">Les Titres-Resto QaliPay™ permettent aux entreprises de fournir une solution
                            de restauration en
                            l’absence de cantine, restaurant d’entreprise ou de local dédié. Ils se présentent sous
                            forme d’une appli
                            ou de carte à puce et ses avantages sont communs aux deux supports.
                        </p>
                        <p class="faq-text">Les collaborateurs peuvent les utiliser dans des restaurants, mais aussi des
                            commerces alimentaires ou
                            en commande en ligne, ce qui leur donne un large choix pour leurs déjeuners.
                        </p>
                        <p class="faq-text">Nous avons donc une solution économique, qui ouvre un grand choix à vos
                            collaborateurs pour leur
                            pause déjeuner, au bureau comme en télétravail.
                        </p>
                    </div>
                    <p class="faq-sub-title">Comment finaliser votre choix ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">L’un des autres critères de calcul du montant des Titres-Resto QaliPay™ sera
                            la capacité financière de votre
                            entreprise.</p>
                        <p class="faq-text">Attention, vous ne pourrez pas jouer sur des critères comme le statut de vos
                            collaborateurs. L’avantage social
                            qu’est le Titre-Resto doit être donné à tous les salariés à égalité, part patronale comprise
                        </p>
                        <p class="faq-text">Il vous faudra donc répondre au besoin du plus grand nombre. En effet, si
                            vous faites le calcul côté salarié, un
                            Titre-Resto au montant trop élevé risqueront de peser trop sur la part salariale et donner
                            une impression mitigée.</p>
                        <p class="faq-text">A l’inverse, si le montant est trop faible, le Titre-Resto risque d’être
                            frustrant car il ne permettra pas de manger
                            correctement tous les jours de travail.</p>
                        <p class="faq-text">Le Titre-Resto n’est pas qu’un coup de pouce financier, c’est aussi
                            l’avantage social préféré des salariés, une
                            véritable source de motivation et de fidélisation pour votre entreprise.</p>
                        <p class="faq-text">Proposé dans une offre d’emploi, le Titre-Resto attire les candidats et
                            montre une image positive de votre
                            entreprise. N’oubliez pas cette dimension dans le calcul du coût Titre-Resto !</p>
                    </div>
                    <p class="faq-sub-title">Les Titre-Resto sont-ils obligatoires ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">Et non ! Les le Titre-Resto ne sont pas obligatoires. Ils sont un avantage
                            social (et même : le préféré des salariés !).</p>
                        <p class="faq-text">Les conditions d’attribution du Titre-Resto doivent être faits sur une base
                            strictement égalitaire.
                        </p>
                        <p class="faq-text">Par exemple, l’endroit où vos salariés travaillent (dans votre entreprise,
                            chez eux, en bureaux partagés, chez un
                            client) ne change aux conditions d’attribution des Titres-Resto .</p>

                    </div>
                    <p class="faq-sub-title">Puis-je partager mes Titres-Resto QaliPay™ avec une tierce personne ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">Il est interdit d’en faire bénéficier des tiers. En effet, les Titres-Resto
                            sont nominatifs et ne doivent être utilisés que
                            pendant les jours ouvrables (sauf cas spécifiques, par exemple si vous travaillez le
                            dimanche ou les jours fériés).</p>
                        <p class="faq-text">En effet, les Titres-Resto sont destinés à assurer un repas aux salariés
                            pendant leur journée de travail.
                        </p>
                        <p class="faq-text">Par exemple, l’endroit où vos salariés travaillent (dans votre entreprise,
                            chez eux, en bureaux partagés, chez un
                            client) ne change aux conditions d’attribution des Titres-Resto .</p>
                        <p class="faq-text">En effet, les Titres-Resto sont destinés à assurer un repas aux salariés
                            pendant leur journée de travail.</p>
                    </div>
                    <p class="faq-sub-title">Quelle est la durée de validité d’un Titre-Resto QaliPay™ ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">Les Titres-Resto QaliPay™ sont valables durant l’année civile dont ils font
                            mention et jusqu’au 31 décembre de
                            l’année en cours.</p>
                    </div>
                    <p class="faq-sub-title">Que deviennent les Titres-Resto QaliPay™ non utilisés en fin de validité ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">Les titres non utilisés au cours de la période de validité sont échangés
                            contre un nombre égal de titres valables
                            pour la période ultérieure.</p>
                    </div>
                    <p class="faq-sub-title">Acheter des Titres-Resto QaliPay™: quelle procédure ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">Quelles sont les étapes pour acheter des Titres-Resto QaliPay™ ? Pour
                            pouvoir proposer des Titres-Resto
                            QaliPay™ à ses employés, l’entreprise doit prendre contact avec QaliPay™ afin de définir ses
                            besoins. Lorsqu’elle
                            passe sa commande, l’entreprise va ensuite donner un certain nombre de détails dont : <br>
                            - La valeur des Titres-Resto QaliPay™ désirée pour chacun des collaborateurs (il est d’usage
                            d’en prendre un par
                            jour travaillé dans le mois écoulé) <br>
                            - Et enfin la liste complète des salariés qui vont bénéficier des Titres-Resto QaliPay™ (le
                            titre doit être légalement
                            nominatif)
                            <br>
                            - Il suffira ensuite de régler la commande selon un des moyens de paiement mis à
                            disposition.
                        </p>
                    </div>
                    <p class="faq-sub-title">Avantages des Titres-Resto QaliPay™ : quels sont-ils ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">Les Titres-Resto QaliPay™ possèdent plusieurs avantages, aussi bien pour
                            l’employé que pour l’employeur.
                            L’avantage des Titres-Resto QaliPay™ principal pour les employés est le fait de leur
                            permettre de se restaurer à un
                            coût réduit puisque l’employeur finance tout ou une partie des Titres-Resto. De plus, les
                            des Titres-Resto QaliPay™
                            ne se limitent pas à une utilisation dans des points de restauration mais peuvent aussi être
                            utilisés en grande
                            surface pour les achats alimentaires.</p>
                        <p class="faq-text">Pour les entreprises, investir dans les des Titres-Resto QaliPay™ présente
                            un double bénéfice. Cela permet
                            d’abord d’attirer et de fidéliser ses employés en prenant en charge une partie de la
                            restauration de ses salariés.
                            Cette prise en charge est simple à mettre en place et ne nécessite donc pas toute la
                            logistique qui serait induite par
                            la mise en place d’un lieu de restauration au sein de l’entreprise. Enfin, en recourant aux
                            des Titres-Resto
                            QaliPay™, l’entreprise profite d’une exonération de charges (à la fois fiscales et sociales)
                            par salarié et par jour
                            travaillé.</p>
                        <p class="faq-text">Les Titres-Resto QaliPay™ sont donc un complément de revenu gagnant-gagnant
                            entre l’entreprise et ses salariés.
                            En tant qu’employeur, vous avez tout intérêt à mettre en place les Titres-Resto QaliPay™ au
                            sein de votre
                            entreprise !</p>
                    </div>
                    <p class="faq-sub-title">Pourquoi choisir la Carte Titres-Resto QaliPay™ ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">La Carte QaliPay Connect™ se démarque par sa simplicité d’utilisation. En
                            effet, la carte QaliPay Connect™
                            assure un paiement sécurisé et peut être équipée d’un code PIN, comme une carte bancaire.
                        </p>
                        <p class="faq-text">En cas de perte ou de vol, l’opposition se fait rapidement en ligne et la
                            nouvelle carte est envoyée au bénéficiaire.
                            La carte permet également de payer le montant du repas au centime près. Fini les avoirs, ou
                            les problèmes de
                            monnaies.
                        </p>
                        <p class="faq-text">Par ailleurs, la carte peut être utilisée tous les mois sans problème.
                            Ecologique, la carte offre une utilisation
                            simplifiée et est 100% rechargeable à distance par l’employeur.
                        </p>
                        <p class="faq-text">Le suivi des transactions en quasi temps réel est très simple grâce à une
                            application mobile.
                        </p>
                        <p class="faq-text">Un autre avantage non négligeable de la Carte QaliPay Connect™ est le
                            complément de paiement. En effet, cette
                            fonctionnalité permet à l’utilisateur d’associer son compte Titres-Resto QaliPay™ avec un
                            autre moyen de
                            paiement comme une carte bancaire ou de l’espèce dans le cas où le montant de la carte ne
                            suffirait pas. Il s’agit
                            d’une excellente opportunité de compléter les paiements au-delà des fonds disponibles en une
                            seule et même
                            transaction.
                        </p>
                    </div>
                    <p class="faq-sub-title">Quel identifiant dois-je utiliser pour me connecter à mon compte personnel
                        employeur QaliPay™ ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">Rassurez-vous, rien ne change pour vous ! Vos identifiant et mot de passe
                            restent les mêmes.</p>
                        <p class="faq-text">Connectez-vous sur votre espace employeur depuis <a
                                href="www.qalipay.com">www.qalipay.com</a>, renseignez
                            vos codes d’accès
                            (identifiant et mot de passe). Et hop ! Vous voilà sur votre espace employeur en ligne.
                        </p>
                    </div>
                    <p class="faq-sub-title">Où puis-je trouver des informations sur la livraison de ma commande en
                        cours ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">Rendez vous directement sur votre Espace Client, dans le menu "Commandes et
                            factures.</p>
                    </div>
                    <p class="faq-sub-title">Quelles sont les caractéristiques de la Carte QaliPay Connect™ ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">La carte QaliPay Connect™ est une carte à puce nominative (avec le nom du
                            porteur)
                            Les cartes sont utilisables grâce à un code pin à 4 chiffres ou grâce au paiement sans
                            contact
                            Elle permet de payer au centime de FCFA près partout dans tous les pays de l’UEMOA, dans un
                            réseau de plus de 10 000
                            établissements.
                        </p>
                        <p class="faq-text">Le support carte est valable 3 ans à compter de la date de fabrication.</p>
                    </div>
                    <p class="faq-sub-title">Qu'est ce que la carte QaliPay Connect™ virtuelle ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">Il s’agit de notre offre Titres-Resto QaliPay™ pour les repas de vos
                            collaborateurs en version totalement
                            dématérialisée, sans support physique. Cette offre leur permet d’effectuer toutes leurs
                            transactions, exclusivement
                            depuis leur smartphone ou montre connectée.
                        </p>
                    </div>
                    <p class="faq-sub-title">Quel montant faut-il recharger sur la carte QaliPay Connect™ de mes
                        salariés ou de mes agents ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">Le montant de votre chargement dépend :
                        </p>
                        <ul>
                            <li class="faq-text">de la valeur des Titres-Resto QaliPay™ dématérialisé que vous
                                choisissez, liée au plafond de 30 000 FCFA par mois, par
                                salarié d'exonération, et, appelée valeur de rechargement.</li>
                            <li class="faq-text">du montant des Titres-Resto QaliPay™ à charger sur le compte : les
                                salariés et les agents peuvent recevoir un montant
                                maximum de 30 000 FCFA de Titres-Resto dématérialisés pris en charge par l’employeur par
                                mois par salarié.</li>
                        </ul>
                        <p class="faq-text">Les jours d’absence (congés, maladies) n’entrent pas dans le calcul des
                            jours travaillés.
                        </p>
                        <p class="faq-text">Vous pouvez choisir la fréquence de rechargement : mensuelle, trimestrielle,
                            semestrielle….
                        </p>
                    </div>
                    <p class="faq-sub-title">Comment modifier les données de mon compte ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">Nous modifions les données de votre compte (valeur faciale, adresse de
                            livraison, interlocuteur de commande...)
                            sur simple demande : </p>
                        <ul>
                            <li class="faq-text">Ecrivez-nous à l'adresse mail suivante : <em>care@qalipay.com</em></li>
                        </ul>
                    </div>

                    <p class="faq-sub-title">Les stagiaires peuvent-ils bénéficier de la carte QaliPay Connect™ ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">Oui. <br>
                            L’attribution d’une carte QaliPay Connect™ n’est admise en principe que pour les salariés de
                            l’entreprise ou les agents
                            de la collectivité. Toutefois, si vous ne disposez pas de réfectoire, vous pouvez faire
                            bénéficier vos stagiaires d’une
                            carte QaliPay Connect™ .</p>
                    </div>
                    <p class="faq-sub-title">Un gérant peut-il bénéficier de la carte QaliPay Connect™ ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">Oui, si les conditions suivantes sont remplies : <br>
                            - avoir le statut de salarié <br>
                            - disposer d'un contrat de travail, traduisant l'existence d'un véritable lien de
                            subordination juridique du titulaire du
                            contrat vis-à-vis de l'entreprise qui l'emploie et le rémunère</p>
                    </div>
                    <p class="faq-sub-title">Des salariés en contrat d’apprentissage ou en contrat de
                        professionnalisation
                        peuvent-ils bénéficier de la carte QaliPay Connect™ ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">Oui, ils peuvent bénéficier d’une carte QaliPay Connect™ pour les jours
                            passés dans votre
                            entreprise.</p>
                        <p class="faq-text">Pour des personnes ne restant que quelques mois, vous pouvez toutefois opter
                            pour la Carte
                            QaliPay Connect™ virtuelle qui peut être une solution plus flexible pour des passages de
                            courte
                            durée.</p>
                    </div>
                    <p class="faq-sub-title">Que se passe-t-il en cas d'erreur de commande sur les chargements de Carte
                        QaliPay Connect™ ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">En cas d'erreur de commande sur les chargements, vous devez avertir vos
                            salariés et procéder à une régularisation.
                            Si le montant est inférieur à ce que le salarié aurait du recevoir, une commande
                            complémentaire peut être enregistrée sur
                            l'Espace Client.
                            Si le montant est supérieur à ce que le salarié aurait du recevoir, le chargement du mois
                            suivant pourra être alloué en
                            conséquence.</p>
                    </div>
                    <p class="faq-sub-title">Que se passe t il en cas d'erreur sur les données bénéficiaires ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">- S'il s'agit d'une erreur sur le nom et le prénom du salarié, vous devez
                            prévenir votre salarié qui pourra tout de même
                            conserver la carte et l'utiliser normalement. <br>
                            - S'il s'agit d'une erreur sur la date de naissance, vous devez prévenir votre salarié pour
                            lui indiquer quelle date de naissance
                            utiliser pour son inscription sur <b>QaliPay Connect™</b> <br>
                            - S'il s'agit d'une erreur sur l'adresse postale, vous devez corriger les données dans le
                            fichier pour les prochaines
                            commandes et contacter <b>QaliPay™</b> afin de mettre à jour la donnée si la carte est en
                            cours de fabrication et d'expédition.</p>
                    </div>
                    <p class="faq-sub-title">Comment mes salariés ou mes agents peuvent-ils accéder à leur Espace
                        Personnel ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">Leur Espace Personnel est accessible depuis le site <b>QaliPay Connect™</b>
                            ou depuis l'application mobile <b>QaliPay Connect™</b> téléchargeable depuis <a
                                href="">l'App Store</a> et <a href="">Google Play</a> . Ils se connectent grâce à un nom
                            d’utilisateur et à un
                            mot de passe qu’ils auront préalablement définis lors de la création de leur compte ainsi
                            que leur date de naissance.</p>
                    </div>
                    <p class="faq-sub-title">Comment puis-je commander mes titres Titres-Resto QaliPay™ ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">Pour passer commande de titres Titres-Resto QaliPay™ : <br>
                            - Rendez vous directement sur votre Espace Client rubrique "COMMANDER <br>
                            - Ou par téléphone au xx xx xx xx xx</p>
                    </div>
                    <p class="faq-sub-title">Y-a-t-il un cofinancement entre l’employeur et le collaborateur ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">Pas nécessairement. La limite de prise en charge pour les <b>Titres-Resto
                                QaliPay™</b> est de 30 000
                            FCFA par salarié, par mois. Le salarié a la possibilité de compléter son budget.</p>
                    </div>
                    <p class="faq-sub-title">Que faire si le colis de cartes QaliPay Connect™ est endommagé ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">N’acceptez pas le colis et contactez le Centre de Relation Clients au xx xx
                            xx xx xx.</p>
                    </div>
                </div>
                <div class="faq-Employes" faq-Employes>
                    <p class="title">Titres-Resto - Employés</p>
                    <p class="faq-sub-title">Quels sont les avantages des Titres-Resto QaliPay™ pour l’employé ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">Le Titre-Resto QaliPay™ est un avantage en nature. C’est un élément
                            complémentaire de rémunération
                            très apprécié par les salariés.</p>
                        <p class="faq-text">Les salariés peuvent avoir une carte restaurant qui leur permet de consulter
                            leur solde restant et de
                            garder l’historique de leurs transactions via une application sur smartphone.</p>
                    </div>
                    <p class="faq-sub-title">Où utiliser les Titres-Resto QaliPay™ ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">Les Titres-Resto QaliPay™ ne sont pas limités aux seuls… restaurant ! Où
                            utiliser les titres restaurant ? En
                            boulangerie, traiteur, chez le primeur, en grande et moyenne surface… le choix est large, du
                            moment que le
                            commerçant est affilié à QaliPay™ pour accepter les Titres-Resto. Attention, en revanche,
                            tous les produits ne
                            sont pas éligibles.</p>
                    </div>
                    <p class="faq-sub-title">Où utiliser nos Titres-Resto QaliPay™ : le principe général ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">Les Titres-Resto QaliPay™ peuvent être utilisés, en dehors du restaurant,
                            pour acheter des préparations
                            alimentaires directement consommables (salades composées, carottes râpées,), à réchauffer
                            (poulet thaï, part de
                            lasagnes, …) ou à décongeler (plat tout prêt, pizza, …), des produits laitiers (yaourt,
                            fromage blanc…) ainsi que
                            des fruits et légumes (directement consommables ou non) et des boissons.</p>

                    </div>
                    <p class="faq-sub-title">Dans les supérettes, moyennes et grandes surfaces, quels sont les produits
                        éligibles aux Titres-Resto
                        QaliPay™ ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">Produits frais : charcuterie, desserts laitiers, fromages, yaourts, fruits
                            et légumes, lait, plats préparés, poisson
                            transformé frais, salades composées, snacking, tartes salées, quiches, pizzas, traiteur,
                            viandes préparées prêtes
                            à cuire, viande transformée fraîche.</p>
                        <p class="faq-text">Épicerie : conserves, plats préparés, poisson transformé, viandes préparées
                            prêtes à cuire, viande transformée,
                            boulangerie hors viennoiseries.</p>
                        <p class="faq-text">Produits surgelés : plats préparés, poisson transformé, snacking, tartes
                            salées, quiches, pizzas, viandes
                            préparées prêtes à cuire, viande transformée.</p>

                    </div>
                    <p class="faq-sub-title">Quels sont les avantages des Titres-Resto QaliPay™ pour les salariés ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">En dehors du soutien au pouvoir d’achat puisque 100% de la valeur des
                            Titres-Resto QaliPay™ peuvent être
                            financé par l’employeur, les Titres-Resto QaliPay™ ouvrent aux collaborateurs un réseau de
                            plus de 10 000
                            commerçants et aux envies alimentaires les plus variées, sur place, à emporter ou à se faire
                            livrer satisfaire
                            toutes les envies.</p>
                        <p class="faq-text">Pour ceux et celles qui bénéficient de la Carte QaliPay Connect™, la
                            simplicité est de mise : paiement au
                            centime près, sans code pin, sans contact, mobile, sur place, en ligne…</p>
                        <p class="faq-text">Les salariés à la carte QaliPay Connect™ ont d’autres avantages : ils
                            peuvent suivre leur solde et leur historique
                            de transactions en direct, géolocaliser les commerçants et contacter l’assistance en ligne.
                        </p>
                        <p class="faq-text">Le Titre-Resto QaliPay™ a d’autres avantages pour la planète : recyclable,
                            la carte permet de faire des dons aux
                            Orphelinats et à Caritas.</p>
                        <p class="faq-text">En bref, comme nous l’avons vu, le Titre-Resto QaliPay™ est plus qu’un moyen
                            de paiement. C’est une foule
                            d’avantages, pour les entreprises comme pour ceux qui en bénéficient !</p>

                    </div>
                    <p class="faq-sub-title">Puis-je commander sur Internet avec Titres-Resto QaliPay™ ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">Vous pouvez passer commande en ligne et payer avec votre carte QaliPay
                            Connect™ sur + de 20 sites
                            Internet et applications mobiles, soit + de 10 000 enseignes dans tous les pays de l’UEMOA.
                        </p>
                        <p class="faq-text">Supermarchés, restaurants, traiteurs, fastfood, épiceries, produits frais,
                            sandwichs, plats cuisinés, cuisine
                            du monde, surgelés, salades… faites-vous plaisir en livraison et en click & collect.</p>
                    </div>
                    <p class="faq-sub-title">Où utiliser mes Titres-Resto QaliPay™ ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">Les Titres-Resto QaliPay™ sont acceptés partout dans tous les restaurants et
                            commerces alimentaires affiliés à
                            QaliPay™.
                        </p>
                        <p class="faq-text">Vous pouvez utiliser vos Titres-Resto QaliPay™ pour payer dans plus de 10
                            000 restaurants et commerces dans
                            tous les pays de l’UEMOA.
                        </p>
                        <p class="faq-text">Votre carte QaliPay Connect™ est une carte VISA UBA qui passe dans tous
                            les terminaux électroniques de
                            paiement. Vous êtes adepte de la commande en ligne ? Vous pouvez payer avec votre carte
                            QaliPay Connect™
                            sur plus de 20 sites Internet, soit plus de 10 000 enseignes !</p>
                        <p class="faq-text">Utiliser QaliPay Connect™ pour commander en ligne <br>
                            Utiliser QaliPay Connect™ au restaurant <br>
                            Utiliser QaliPay Connect™ en supermarchés et en grandes surfaces <br>
                            Utiliser QaliPay Connect™ dans les commerces de bouche /proximité <br>
                            Utiliser QaliPay Connect™ dans les chaînes, grandes enseignes de restauration <br>
                            Utiliser QaliPay Connect™ sur l’autoroute, dans les gares et les aéroports <br>
                            Utiliser QaliPay Connect™ dans les magasins bio <br>
                            Utiliser QaliPay Connect™ dans les fast foods <br>
                            Trouvez ou déjeuner avec votre carte QaliPay Connect™ dans la rubrique « Où l’utiliser » de
                            votre espace
                            personnel QaliPay™ , accessible via l’appli mobile disponible sur Google Play et l’App
                            Store, ou via le site web
                            QaliPay™ , rubrique « Connectez-vous ».</p>
                    </div>
                    <p class="faq-sub-title">Quand est rechargé mon solde carte QaliPay Connect™ ?
                    </p>
                    <div class="faq-describe">
                        <p class="faq-text">Votre compte carte QaliPay Connect™ est rechargé dès que votre employeur
                            nous en donne la consigne. C’est
                            votre employeur qui est décisionnaire du montant et de la date de votre chargement QaliPay
                            Connect™ . Votre
                            solde carte QaliPay Connect™ n’est donc pas automatiquement chargé à date fixe tous les
                            mois.
                        </p>
                        <p class="faq-text">Pour être informé en temps réel du rechargement de votre compte carte
                            QaliPay Connect™, activez les alertes
                            e-mail !</p>
                        <p class="faq-text">Voici comment procéder : <br>
                            Rendez-vous sur votre espace personnel QaliPay Connect™, via l’appli mobile disponible sur
                            Google Play et
                            l’App Store ou sur <a href="www.qalipay.com">www.qalipay.com</a>.</p>
                    </div>
                </div>
            </div>
        </section>
    </main>


    <?php
    require APPROOT . '/views/includes/footer.php';
?>