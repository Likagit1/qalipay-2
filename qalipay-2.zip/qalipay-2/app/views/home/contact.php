<?php
    require APPROOT . '/views/includes/head.php';
?>
<?php
    require APPROOT . '/views/includes/nav.php';
?>


<main>
<section>
    <div class="contact-container">
        <div class="contact-card">
            <h1 class="contact-card-title" data-i18n="contact-title" id="contact-title">Contactez-Nous !</h1>
            <div class="contact-card-items">
                <form class="contact-item-form" method="post" id="contact-Form" onsubmit="return submitForm()">
                    <div class="successMessage" id="successMessage" data-i18n="success-message" id="success-message">
                        Le formulaire a été soumis avec succès !
                    </div>
                    <div class="errorMessage" id="errorMessage" data-i18n="error-message" id="error-message">
                        Erreur !
                    </div>
                    <div class="item-contact">
                        <label for="name" data-i18n="label-name" id="label-name">Nom & Prénoms</label> <span style="color: red;">*</span>
                        <input type="text" id="name" name="name" placeholder="Entrez votre nom et prenom" required>
                    </div>
                    <div class="item-contact">
                        <label for="email" data-i18n="label-email" id="label-email">Email </label><span style="color: red;">*</span>
                        <input type="email" id="email" name="email" placeholder="Entrez votre email" >
                    </div>
                    <div class="item-contact">
                        <label for="telephone" data-i18n="label-telephone" id="label-telephone">Téléphone</label> <span style="color: red;">*</span>
                        <input type="tel" name="tel" id="telephone" placeholder="Entrez votre numero" >
                    </div>
                    <div class="item-contact">
                        <label for="company" data-i18n="label-company" id="label-company">Entreprise / Organisation</label> <span style="color: red;">*</span>
                        <input type="text" id="company" name="entreprise" placeholder="Entrez le nom de votre Entreprise / Organisation" required>
                    </div>
                    <div class="item-contact">
                        <label for="post" data-i18n="label-post" id="label-post">Fonction</label> <span style="color: red;" >*</span>
                        <input type="text" name="fonction" id="post" placeholder="Votre Fonction" >
                    </div>
                    <div class="item-contact">
                        <label for="message" data-i18n="label-message" id="label-message">Message</label> <span style="color: red;">*</span>
                        <textarea class="contact-message" name="message" id="message" rows="10" cols="15" placeholder="Entrez votre message"></textarea>
                    </div>
                    <div class="item-contact-btn">
                        <button type="submit" id="sendForm" class="contact-button" data-i18n="button-send" id="button-send">Envoyer</button>
                    </div>
                </form>
                <div class="contact-info">
                    <img src="assets/contact.jpg" width="440px" height="320px" alt="">
                    <div class="contact-info-text">
                        <p class="info-text" ><i class="fas fa-map-marker-alt"></i> Côte d’Ivoire, Abidjan, Cocody, II Plateaux Mobile</p>
                        <p class="info-text" ><i class="fas fa-phone"></i> +225 27 22 42 78 85 / 05 06 34 34 99</p>
                        <p class="info-text" ><i class="fas fa-envelope"></i>hello@qalipay.org</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

    </main>

<?php
    require APPROOT . '/views/includes/footer.php';
?>