<?php 
    require APPROOT . '/views/includes/head.php';
?>
    <?php
    require APPROOT . '/views/includes/nav.php';
?>
    <main>
    <section >
    <div class="cover-container" >
        <div class="cover-left" >
            <img src="assets/Front_card_Qalipay 2.png" alt="Qalipay Card" >
        </div>
        <div class="cover-right" >
            <h1 data-i18n="simplifiez-vie-salaries" id="simplifiez-vie-salaries">Simplifiez la vie de vos salariés!</h1>
            <p data-i18n="texte-vie-salaries" id="texte-vie-salaries">
                Que vous soyez DIRIGEANT, DAF, DRH, RRH, etc. d’une Grande Entreprise ou d’une START UP, TPE, PME ou d’une COLLECTIVITÉ, QaliPay™ est la solution qui accompagne vos salariés au quotidien et vous simplifie la vie.
            </p>
            <a class="cover-btn" href="contact.html" data-i18n="prenez-rendez-vous" id="prenez-rendez-vous">Prenez un rendez-vous</a>
        </div>
    </div>
</section>
<section >
    <div class="adventure-container" >
        <h1 class="title" data-i18n="participez-aventure-qalipay" id="participez-aventure-qalipay">Prenez part à l’aventure QaliPay !</h1>
        <div class="cards-adventure" >
            <div class="card adventure-card1">
                <img src="assets/group-afro.png" class="cards-img" alt="" >
                <div class="text-card" >
                    <p class="card-title" data-i18n="pour-tous-employeurs" id="pour-tous-employeurs">Pour tous les employeurs</p>
                    <p class="text" data-i18n="description-employeurs" id="description-employeurs">Privés ou publics, à partir d’un (1) salarié: TPE, PME, Grande Entreprise, Start-up, collectivités, secteurs publics, ambassades, associations, etc.</p>
                </div>
            </div>
            <div class="card adventure-card2" >
                <img src="assets/group-afro-americans.png" class="cards-img" alt="" >
                <div class="text-card" >
                    <p class="card-title" data-i18n="pour-tous-employes" id="pour-tous-employes">Pour tous les employés</p>
                    <p class="text" data-i18n="description-employes" id="description-employes">Salariés du privé, fonctionnaires du public, contractuels, stagiaires, etc.</p>
                </div>
            </div>
        </div>
        <a class="btn-adventure" href="Commentcamarche.html" data-i18n="decouvrez-comment-ca-marche" id="decouvrez-comment-ca-marche">Découvrez comment ça marche <i style="height: 15px;" class="fa fa-arrow-right" aria-hidden="true"></i></a>
    </div>
</section>

        
        <section>
            <div class="about-container">
            <div class="about-right">
    <p class="title-about" data-i18n="restaurateur-or-merchant" id="restaurateur-or-merchant">Vous êtes restaurateur ou commerçant ?</p><br>
    <p class="text-about">
        <span data-i18n="join-qalipay-network" id="join-qalipay-network">Vous possédez un restaurant ou un magasin et souhaitez rejoindre le réseau des </span>
        <b data-i18n="qalipay-restaurant-vouchers" id="qalipay-restaurant-vouchers">Titres-Resto QaliPay™</b>
        <span data-i18n="another-key-for-turnover" id="another-key-for-turnover">, le partenaire numéro un des restaurateurs en Afrique ? </span> <br><br>
        <b data-i18n="qalipay-restaurant-vouchers2" id="qalipay-restaurant-vouchers2">Les Titres-Resto QaliPay™</b>
        <span data-i18n="additional-customers-increase-turnover" id="additional-customers-increase-turnover"> garantissent l'attraction de clients supplémentaires et une augmentation de votre chiffre d'affaires.</span>
    </p><br>
    <a href="Commentcamarche.html#comment" class="text-sub" data-i18n="discover-how-it-works" id="discover-how-it-works">Découvrez comment ça fonctionne <i style="height: 15px;" class="fa fa-arrow-right" aria-hidden="true"></i></a>
</div>

                <img src="assets/focus.png" class="img-about" alt="">
            </div>
        </section>
        
        <section>
            <div class="avantage">
            <h1 class="title" data-i18n="vos-avantages-qalipay-title" id="vos-avantages-qalipay-title"> Vos avantages Titres-Resto QaliPay™</h1>
                <div class="avantage-container">
                    <div class="avantage-card avantage-card1">
                        <img src="assets/group-afro.png" class="avantage-img" alt="">
                        <div class="text-av">
                        <p class="avantage-card-title" data-i18n="avantages-employeurs" id="avantages-employeurs">Avantages employeurs</p>
                            <div class="avantage-text-container">
                                <ul class="avantage-text-card">
                                  <li class="avantage-text">
                                    <b data-i18n="avantage-en-nature" id="avantage-en-nature">Un avantage en nature</b>
                                    <span data-i18n="pour-motiver-salarie" id="pour-motiver-salarie">pour motiver et fidéliser les salariés</span>
                                  </li>

                                  <li class="avantage-text">
                                    <b data-i18n="zero-charge" id="zero-charge">Zéro charge :</b>
                                    <span data-i18n="exonerations-fiscales" id="exonerations-fiscales">exonérations fiscales et sociales déductibles du bénéfice imposable des sommes financées</span>
                                  </li>

                                  <li class="avantage-text">
                                    <b data-i18n="mise-en-place" id="mise-en-place">Mise en place simple et rapide</b><span data-i18n="mise-en-place-text" id="mise-en-place-text">, sans engagement de durée</span>
                                  </li>
                                  <li class="avantage-text">
                                    <b data-i18n="expert-dedie" id="expert-dedie">Un expert dédié pour vous accompagner</b><span data-i18n="expert-dedie-text" id="expert-dedie-text"> tout au long de votre contrat</span>
                                    </li>

                                    <li class="avantage-text">
    <span data-i18n="depuis-espace-client" id="depuis-espace-client">Depuis </span> <b data-i18n="votre-espace-client" id="votre-espace-client">votre espace client, suivez et renouvelez vos commandes</b> <span data-i18n="autonomie-collaborateurs" id="autonomie-collaborateurs">en toute autonomie et sans contrainte d’horaires, gérez vos collaborateurs, etc.</span>
</li>
<li class="avantage-text">
    <span data-i18n="titres-resto-qalipay" id="titres-resto-qalipay">Titres-Resto QaliPay™</span> <b data-i18n="valable-3-ans" id="valable-3-ans">valable 3 ans</b>
</li>

                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="avantage-card avantage-card2">
                        <img src="assets/group-afro-americans.png" class="avantage-img" alt="">
                        <div class="text-av">
                        <p class="avantage-card-title" data-i18n="avantages-employes" id="avantages-employes">Avantages employés</p>

                            <div class="avantage-text-container">
                                <ul class="avantage-text-card">

                                  <li class="avantage-text">
                                    <b data-i18n="carte-acceptee-partout" id="carte-acceptee-partout">La carte acceptée partout :</b>
                                    <span data-i18n="commerces-restaurants-fastfood" id="commerces-restaurants-fastfood">jusqu’à 10 000 commerces, restaurants, fastfood connectés via les sites et applis de livraison.</span>
                                    <a href="#" data-i18n="decouvrez-restaurants-autour" id="decouvrez-restaurants-autour">Découvrez en un clin d’œil les restaurants autour de vous</a>
                                  </li>

                                  <li class="avantage-text">
                                    <b data-i18n="payez-repas-peu-importe-montant" id="payez-repas-peu-importe-montant">Payez tous vos repas, peu importe le montant !</b>
                                    <span data-i18n="depenses-depassent-avoir" id="depenses-depassent-avoir">vos dépenses dépassent votre avoir sur la carte ou l’appli ? Pas de souci ! vous pouvez associer votre carte bancaire ou compléter via Mobile Money pour payer la différence.</span>
                                    <a href="#" data-i18n="commandez-carte" id="commandez-carte">Commandez la carte</a>
                                  </li>

                                  <li class="avantage-text">
                                    <b data-i18n="gagnez-du-temps-a-la-caisse" id="gagnez-du-temps-a-la-caisse">Gagnez du temps à la caisse, </b>
                                    <span data-i18n="payez-sans-contact" id="payez-sans-contact">payez sans contact avec votre carte ou votre smartphone. En cas de besoin, retrouvez votre code PIN sur l’appli QaliPay Connect™. La carte QaliPay Connect™ est également disponible sur tous les smartphones (Google Pay, Samsung Pay, Apple Pay).</span>
                                    <a href="#" data-i18n="decouvrez-paiement-mobile" id="decouvrez-paiement-mobile">Découvrez le paiement mobile</a>
                                  </li>

                                  <li class="avantage-text">
                                    <b data-i18n="plus-de-20-partenaires-online" id="plus-de-20-partenaires-online">+ de 20 partenaires online :</b>
                                    <span data-i18n="liste-partenaires" id="liste-partenaires">JumiaFoods / Glovo / Yango Deli / LivreurBi / Dakarfooddelivery / Livrema / Eat Me / City Food / BonBiz Food / Conekto Food / Tôtô Riibo / Zemfood / Ahiyoyo Food / Kaba Food Delivery / Delivroum / GuiFood / Direct Resto / HeyFood etc...</span>
                                    <a href="#" data-i18n="decouvrez-plateformes-partenaires" id="decouvrez-plateformes-partenaires">Découvrez les plateformes partenaires</a>
                                  </li>

                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <a class="btn-avantage" href="contact.html" data-i18n="prenez-rendez-vous" id="prenez-rendez-vous">
    Prenez un rendez-vous <i style="height: 15px;" class="fa fa-arrow-right" aria-hidden="true"></i>
</a>
            </div>
        </section>
        <section>
            <div class="carteResto-container">
            <h1 class="title" data-i18n="carte-qalipay-simplifie-vie" id="carte-qalipay-simplifie-vie">Carte QaliPay Connect™ : choisissez la carte qui vous simplifie la vie !</h1>

                <div class="card-carteResto">
                    <div class="images-container">
                        <div class="images">
                            <div>
                                <img src="assets/Back_card.png" class="imgx" alt="">
                            </div>
                            <div>
                                <img src="assets/Front_card.png" class="imgx" alt="">
                            </div>

                        </div>
                    </div>
                    <div class="carteResto-text">
                    <p class="sup-text" data-i18n="vivez-lexperience-qalipay" id="vivez-lexperience-qalipay">Vivez L’expérience Titres-Resto QaliPay™</p><br>
                        <ul>
                           <li class="sub-text" data-i18n="dejeunez-ou-vous-voulez" id="dejeunez-ou-vous-voulez">
                              Déjeunez où vous voulez, au bureau, chez vous, quand vous voulez, dans une heure ou maintenant, comme vous voulez, au restaurant, en livraison, à la cantine avec vos collègues, vos amis, en famille...
                            </li><br>
                            <li class="sub-text" data-i18n="experience-qalipay-bons-plans" id="experience-qalipay-bons-plans">
                                Faites l'expérience Titres-Resto QaliPay™ : des Bons plans exclusifs, pas de limite de paiement.
                            </li><br>
                            <li class="sub-text" data-i18n="carte-qalipay-valable-3-ans" id="carte-qalipay-valable-3-ans">
                                La Carte QaliPay Connect™ est valable 3 Ans et se charge à distance en un clic !
                            </li>

                            </li><br>
                        </ul>
                    </div>

                </div>


            </div>


        </section>

        <section>
            <div class="gestion-container">
            <h1 class="title" data-i18n="une_carte_qalipay_connect" id="une_carte_qalipay_connect">Une Carte QaliPay Connect™ waouh !!!</h1>

                <div class="card-container">

                    <ul class="gestion-text">
                    <li data-i18n="suivre-depenses" id="suivre-depenses">
                        Suivre les dépenses en temps réel
                    </li>
                    <li data-i18n="geolocaliser-commerces" id="geolocaliser-commerces">
                        Géolocaliser les restos et commerces autour de vous
                    </li>
                    <li data-i18n="historique-transactions" id="historique-transactions">
                        Voir votre historique de transactions
                    </li>
                    <li data-i18n="consulter-code-confidentiel" id="consulter-code-confidentiel">
                        Consulter et rééditer votre code confidentiel
                    </li>
                    <li data-i18n="recharger-compte" id="recharger-compte">
                        Recharger et être notifié quand le compte est rechargé
                    </li>
                    <li data-i18n="bloquer-carte" id="bloquer-carte">
                        Bloquer votre carte Titres-Resto® temporairement ou faire opposition en cas de perte/vol – solde garanti !
                    </li>
                    <li data-i18n="associer-cartes" id="associer-cartes">
                        Possibilité d’associer votre Carte Visa UBA et Mobile Money avec votre Carte QaliPay Connect™ pour payer vos additions au-delà du plafond mensuel en un seul geste !
                    </li>

                    </ul>

                    <div class="imgs-container">
                        <div class="imgs">
                            <div>
                                <img src="assets/Back_card.png" class="imgx" alt="">
                            </div>
                            <div>
                                <img src="assets/Front_card.png" class="imgx" alt="">
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section>
            <div class="simulation-container">
            <h1 class="title" data-i18n="simulez-vos-avantages" id="simulez-vos-avantages">
                    Simulez vos avantages grâce aux Titres-Resto QaliPay™
                </h1>
                <p class="simulation-explain" data-i18n="expliquez-votre-structure" id="expliquez-votre-structure">
                    Dites-nous un peu plus sur votre structure et découvrez les économies réalisables grâce à notre solution Titres-Resto QaliPay™.<br>La règlementation en vigueur fixe le plafond d’exonération du Titre-resto à 30 000 FCFA par mois par salarié.
                </p>

                <div class="card-items">
    <div class="card-item-form">
        <form class="item-form" id="simulation-form">
            <div class="input-container-form">
                <label for="nbsal" data-i18n="nombre-salaries" id="nombre-salaries">
                    Nombre de salariés</label><span style="color: red;" >*</span>
                
                <input type="number" id="nbsal" placeholder="Ex : 10" min="1" value="1">
            </div>
            <div class="input-container-form">
                <label for="budgetAlloue" data-i18n="budget-alloue" id="budget-alloue">
                    Budget alloué par mois / salariés</label> <span style="color: red;">*</span>
                
                <input type="number" id="budgetAlloue" placeholder="Ex : 10000" min="5000">
            </div>
        </form>
    </div>
    <div class="card-item-result">
        <p class="result-title" data-i18n="resultat-simulation" id="resultat-simulation">
            Résultat de votre simulation
        </p>
        <div class="result-sold">
            <p class="text-sold" data-i18n="part-entreprise" id="part-entreprise">
                Part payée par l'entreprise :
            </p>
            <p class="price-sold" id="soldEntreprise">0 FCFA</p>
        </div>
        <div class="result-items">
            <div class="card-economie">
                <p class="card-economie-text-sup" data-i18n="economie-entreprise" id="economie-entreprise">
                    Économie pour votre entreprise
                </p>
                <p class="card-economie-text-center" data-i18n="month" id="month">O FCFA / mois d'economie mensuelle</p>
                <p class="card-economie-text-center" data-i18n="year" id="year">O FCFA / an d'economie annuelle</p>
                <p class="card-economie-text-sub" data-i18n="charges-patronales" id="charges-patronales">
                    en charges patronales par rapport à une augmentation de salaire
                </p>
            </div>
        </div>
        <div class="result-items">
            <div class="card-economie">
                <p class="card-economie-text-sup" data-i18n="economie-salaries" id="economie-salaries">
                    Économie pour vos salariés
                </p>
                <p class="card-economie-text-center" id="yearSalarie">O FCFA / an</p>
                <p class="card-economie-text-sub" data-i18n="pouvoir-achat" id="pouvoir-achat">
                    de gain de pouvoir d’achat annuel par rapport à une augmentation de salaire
                </p>
            </div>
        </div>
        <div class="result-btn">
            <a href="contact.html" class="simulation-submit2" data-i18n="prendre-rendez-vous" id="prendre-rendez-vous">
                Prendre un rendez-vous
            </a>
        </div>
    </div>
</div>

            </div>
        </section>
    </main>
   

<?php
    require APPROOT . '/views/includes/footer.php';
?>

	


    