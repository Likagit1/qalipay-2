<?php
    require APPROOT . '/views/includes/head.php';
?>
<?php
    require APPROOT . '/views/includes/nav.php';
?>

<main>
        <section class="page-3">
            <div class="cover-3">
                <img src="assets/femme.png" class="img-cover3" alt="">
                <p class="text-cover3" data-i18n="where-to-use-title" id="where-to-use-title">Où Utiliser Vos Titres-Resto QaliPay™ ?</p>

            </div>
            <!-- <div class="card-input">
                <div class="select">
                    <select>
                        <option value="0" selected disabled="disabled">Selectioner un type de restaurant</option>
                        <option value="1">Restaurant africain</option>
                        <option value="2">fast food</option>
                        <option value="3">snack</option>
                    </select>
                </div>
            </div> -->

            <div class="card-map">
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3972.3099562032926!2d-4.000460326225085!3d5.369610694609244!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfc1955a2b5e402d%3A0xf0bd8e9f706d7e27!2sHLC%20C%C3%B4te%20d&#39;Ivoire!5e0!3m2!1sfr!2sci!4v1692890739383!5m2!1sfr!2sci"
                    width="100%" height="779" style="border:0;" allowfullscreen="" loading="lazy"
                    referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </section>
    </main>

<?php
    require APPROOT . '/views/includes/footer.php';
?>