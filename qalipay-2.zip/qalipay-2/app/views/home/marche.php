<?php
    require APPROOT . '/views/includes/head.php';
?>
<?php
    require APPROOT . '/views/includes/nav.php';
?>

<main>
        <section class="cover-2">
            <div class="cover-text">
            <h1 data-i18n="comment-ca-marche" id="comment-ca-marche">Comment ça marche ?</h1>
          <p data-i18n="developpez-activite" id="developpez-activite">Développez votre activité en toute simplicité !</p>

            </div>
            <div></div>
        </section>
        <section class="step-section">
            <div class="step-card">
                <p class="title-card">Commandez vos Titres-Resto QaliPay™ en 4 étapes
                </p>
                <div class="step">
                    <div class="step-1">
                        <div class="step-number">01</div>
                        <p class="step-sup" data-i18n="etape1-title" id="etape1-title">Étape 1 : Prenez un rdv</p>
                        <p class="step-text" data-i18n="etape1-text" id="etape1-text">Remplissez un formulaire en 2mn et un conseiller vous contactera en moins de 2h.</p>

                    </div>
                    <div class="step-2">
                        <div class="step-number">02</div>
                        <p class="step-sup" data-i18n="etape2-title" id="etape2-title">Étape 2 : échangez sur votre besoin</p>
                        <p class="step-text" data-i18n="etape2-text" id="etape2-text">Validez avec votre conseiller QaliPay, les modalités de mise en place des Titres-Resto QaliPay™ dans votre organisation.</p>

                    </div>
                    <div class="step-3">
                        <div class="step-number">03</div>
                        <p class="step-sup" data-i18n="etape3-title" id="etape3-title">Étape 3 : Attribuez les montants à vos salariés !</p>
                        <p class="step-text" data-i18n="etape3-text" id="etape3-text">Votre espace client est créé, vous pouvez en quelques clics attribuer les montants que vous souhaitez à vos salariés selon leurs besoins et selon votre budget.</p>

                    </div>
                    <div class="step-4">
                        <div class="step-number">04</div>
                        <p class="step-sup" data-i18n="etape4-title" id="etape4-title">Étape 4 : Vos salariés profitent de leurs avantages sur QaliPay !</p>
                        <p class="step-text" data-i18n="etape4-text" id="etape4-text">Vos salariés retrouvent leurs avantages salariés sur la plateforme QaliPay™, l’appli ou avec la Carte QaliPay Connect™ dans notre réseau de prestataires (restaurants, etc.) d’acceptation.</p>

                        </p>
                    </div>
                </div>
                <div class="card-btn">
                    <a href="contact.html">
                        <div class="card-btn-1" data-i18n="prenez-rendez-vous" id="prenez-rendez-vous">
                            Prenez un rendez-vous
                        </div>
                    </a>
                </div>
            </div>
        </section>
        <section class="join" id="comment">
    <img src="assets/chef-cuisinier.png" class="img-join" alt="">
    <div class="join-text">
        <p class="join-title" data-i18n="join-title" id="join-title">Rejoignez le réseau d’acceptation Titres-Resto QaliPay™</p><br>
        <ol>
            <li>
                <p class="join-list" data-i18n="join-step1" id="join-step1">Faites votre demande d’agrément</p>
                <p class="join-list-sub" data-i18n="join-step1-sub" id="join-step1-sub">Pour accepter les paiements de nos Titres-Resto QaliPay™ au sein de votre établissement, vous devez disposer d’un agrément délivré par QaliPay™.</p>
            </li><br>
            <li>
                <p class="join-list" data-i18n="join-step2" id="join-step2">Affiliez-vous à notre réseau</p>
                <p class="join-list-sub" data-i18n="join-step2-sub" id="join-step2-sub">Pour garantir les remboursements de nos Titres-Resto QaliPay™, vous devez vous affilier à notre réseau directement en ligne.</p>
            </li><br>
            <li>
                <p class="join-list" data-i18n="join-step3" id="join-step3">Encaissez vos clients</p>
                <p class="join-list-sub" data-i18n="join-step3-sub" id="join-step3-sub">Vos clients payent dans votre point de vente ou en ligne comme ils le souhaitent à hauteur de 1 500 FCFA ou plus (budget estimatif journalier alloué par leur entreprise). Ils peuvent payer au-delà du plafond quotidien en payant la différence avec un autre moyen de paiement.</p>
            </li><br>
            <li>
                <p class="join-list" data-i18n="join-step4" id="join-step4">Faites-vous rembourser</p>
                <p class="join-list-sub" data-i18n="join-step4-sub" id="join-step4-sub">Profitez d’un remboursement hebdomadaire de l’ensemble des transactions EN LIGNE ou via LES CARTES de nos clients. Retrouvez l’ensemble de ces transactions dans une facture unique dématérialisée sur votre Espace Partenaire.</p>
            </li>
        </ol>
    </div>
</section>

<section class="help">
    <div>
        <p class="help-title" data-i18n="help-title" id="help-title">Besoin d'aide ?</p>
        <p class="help-text" data-i18n="help-text" id="help-text">Vous avez des questions concernant le fonctionnement de Qalipay™ ?</p>
        <a href="contact.html">
            <div class="help-link" data-i18n="help-link" id="help-link">
                Contactez-nous ! <i style="height: 15px;" class="fa fa-arrow-right" aria-hidden="true"></i>
            </div>
        </a>
    </div>
    <div></div>
</section>

    </main>

<?php
    require APPROOT . '/views/includes/footer.php';
?>